package View;

import Connection.MyConnection;

public class TelaPrincipal extends javax.swing.JFrame {

    MyConnection conecta = new MyConnection();

    public TelaPrincipal() {
        initComponents();
        conecta.Connection();

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jInternalBemVindo = new javax.swing.JInternalFrame();
        jPanelInterno = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jButtonCadImagem = new javax.swing.JButton();
        jButtonCadVideo = new javax.swing.JButton();
        jButtonCadTexto = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jButtonFechar = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItemMenu = new javax.swing.JMenuItem();
        jMenuSair = new javax.swing.JMenu();
        jMenuItemSair = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jInternalBemVindo.setTitle("Bem-Vindo");
        jInternalBemVindo.setVisible(true);

        jPanelInterno.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel2.setText("Gerenciar:");

        jButtonCadImagem.setText("Imagem");
        jButtonCadImagem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCadImagemActionPerformed(evt);
            }
        });

        jButtonCadVideo.setText("Vídeo");
        jButtonCadVideo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCadVideoActionPerformed(evt);
            }
        });

        jButtonCadTexto.setText("Texto");
        jButtonCadTexto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCadTextoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanelInternoLayout = new javax.swing.GroupLayout(jPanelInterno);
        jPanelInterno.setLayout(jPanelInternoLayout);
        jPanelInternoLayout.setHorizontalGroup(
            jPanelInternoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanelInternoLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addGap(31, 31, 31)
                .addComponent(jButtonCadImagem)
                .addGap(31, 31, 31)
                .addComponent(jButtonCadVideo)
                .addGap(29, 29, 29)
                .addComponent(jButtonCadTexto)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanelInternoLayout.setVerticalGroup(
            jPanelInternoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelInternoLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanelInternoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButtonCadImagem)
                    .addComponent(jButtonCadVideo)
                    .addComponent(jLabel2)
                    .addComponent(jButtonCadTexto))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel1.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel1.setText("Sistema Gerenciador de Arquivos:");

        jButtonFechar.setText("Fechar");
        jButtonFechar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonFecharActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jInternalBemVindoLayout = new javax.swing.GroupLayout(jInternalBemVindo.getContentPane());
        jInternalBemVindo.getContentPane().setLayout(jInternalBemVindoLayout);
        jInternalBemVindoLayout.setHorizontalGroup(
            jInternalBemVindoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jInternalBemVindoLayout.createSequentialGroup()
                .addGroup(jInternalBemVindoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jInternalBemVindoLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanelInterno, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jInternalBemVindoLayout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 303, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButtonFechar)
                        .addGap(14, 14, 14)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jInternalBemVindoLayout.setVerticalGroup(
            jInternalBemVindoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jInternalBemVindoLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jInternalBemVindoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jButtonFechar))
                .addGap(18, 18, 18)
                .addComponent(jPanelInterno, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(88, Short.MAX_VALUE))
        );

        jMenu1.setText("Iniciar");

        jMenuItemMenu.setText("Menu");
        jMenuItemMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemMenuActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItemMenu);

        jMenuBar1.add(jMenu1);

        jMenuSair.setText("Sair");

        jMenuItemSair.setText("Sair");
        jMenuItemSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemSairActionPerformed(evt);
            }
        });
        jMenuSair.add(jMenuItemSair);

        jMenuBar1.add(jMenuSair);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jInternalBemVindo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jInternalBemVindo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 9, Short.MAX_VALUE))
        );

        setSize(new java.awt.Dimension(448, 291));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonCadImagemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCadImagemActionPerformed

        CadImagem tela = new CadImagem();
        tela.setVisible(true);
    }//GEN-LAST:event_jButtonCadImagemActionPerformed

    private void jButtonFecharActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonFecharActionPerformed
        jInternalBemVindo.dispose();
        conecta.Dosconecta();
    }//GEN-LAST:event_jButtonFecharActionPerformed

    private void jMenuItemSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemSairActionPerformed
        System.exit(0);
        conecta.Dosconecta();
    }//GEN-LAST:event_jMenuItemSairActionPerformed

    private void jButtonCadVideoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCadVideoActionPerformed

        CadVideo tela = new CadVideo();
        tela.setVisible(true);

    }//GEN-LAST:event_jButtonCadVideoActionPerformed

    private void jButtonCadTextoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCadTextoActionPerformed

        CadTexto tela = new CadTexto();
        tela.setVisible(true);

    }//GEN-LAST:event_jButtonCadTextoActionPerformed

    private void jMenuItemMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemMenuActionPerformed

        jInternalBemVindo.setVisible(true);

    }//GEN-LAST:event_jMenuItemMenuActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaPrincipal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonCadImagem;
    private javax.swing.JButton jButtonCadTexto;
    private javax.swing.JButton jButtonCadVideo;
    private javax.swing.JButton jButtonFechar;
    private javax.swing.JInternalFrame jInternalBemVindo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItemMenu;
    private javax.swing.JMenuItem jMenuItemSair;
    private javax.swing.JMenu jMenuSair;
    private javax.swing.JPanel jPanelInterno;
    // End of variables declaration//GEN-END:variables
}
