package Model;

public class Texto extends Arquivo {

    public Texto(Integer _id, String _nome, String _Data, String _Tipo, String _Tamanho) {
        super(_id, _nome, _Data, _Tipo, _Tamanho);
    }

    private String num_palavras;
    private String extencao;
    private String pesquisa;
    private String caminho;

    public Texto() {
    }

    public String getNum_palavras() {
        return num_palavras;
    }

    public void setNum_palavras(String num_palavras) {
        this.num_palavras = num_palavras;
    }

    public String getExtencao() {
        return extencao;
    }

    public void setExtencao(String extencao) {
        this.extencao = extencao;
    }

    public String getPesquisa() {
        return pesquisa;
    }

    public void setPesquisa(String pesquisa) {
        this.pesquisa = pesquisa;
    }

    public String getCaminho() {
        return caminho;
    }

    public void setCaminho(String caminho) {
        this.caminho = caminho;
    }

    @Override
    public int getId() {
        return id;
    }

    @Override
    public String getNome() {
        return nome;
    }

    @Override
    public String getData() {
        return Data;
    }

    @Override
    public String getTipo() {
        return Tipo;
    }

    @Override
    public String getTamanho() {
        return Tamanho;
    }

}
