package Controller;

import Connection.MyConnection;
import Model.*;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.swing.JOptionPane;

public class CadVideos {

    MyConnection conex = new MyConnection();
    Arquivo vdo = new Video();

    public void Salvar(Video vdo) {
        conex.Connection();
        try {

            PreparedStatement pst = conex.con.prepareStatement("insert into arquivos (Tipo, ID, Nome, Tamanho, Data_Arq) values(?,?,?,?,?)");
            pst.setInt(2, vdo.getId());
            pst.setString(1, vdo.getTipo());
            pst.setString(3, vdo.getNome());
            pst.setString(4, vdo.getTamanho());
            pst.setString(5, vdo.getData());
            pst.execute();
            PreparedStatement pst1 = conex.con.prepareStatement("insert into video (Extensão_Vid, Duração, Qualidade_vid, ID_VID, caminho) values(?,?,?,?,?)");
            pst1.setString(2, vdo.getDuracao());
            pst1.setString(3, vdo.getQualidade());
            pst1.setString(1, vdo.getExtencao());
            pst1.setInt(4, vdo.getId());
            pst1.setString(5, vdo.getCaminho());
            pst1.execute();
            JOptionPane.showMessageDialog(null, "Dados inseridos com sucesso.");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao inserir dados." + ex);
        }
        conex.Dosconecta();
    }

    public Video buscaVideo(Video vdo) {
        //instanciar conexão
        conex.Connection();
        conex.executaSql("SELECT ID_VID, Nome, Tipo, Extensão_Vid FROM arquivos, imagem WHERE ID_VDO LIKE'%" + vdo.getPesquisa() + "%'");
        try {
            conex.rs.first();
            vdo.setId(conex.rs.getInt("ID_IMG"));
            vdo.setNome(conex.rs.getString("Nome"));
            vdo.setExtencao(conex.rs.getString("Extensão_Vid"));
            vdo.setTipo(conex.rs.getString("Tipo"));
        } catch (SQLException ex) {
            JOptionPane.showConfirmDialog(null, "Erro de banco" + ex);
        }
        conex.Dosconecta();

        return vdo;
    }

    public void Editar(Video vdo) {
        conex.Connection();
        try {

            PreparedStatement pst = conex.con.prepareStatement("update arquivos set ID = ?, Tipo = ?, Nome = ?, Tamanho = ?, Data_Arq = ? where ID = ?");
            pst.setInt(1, vdo.getId());
            pst.setString(2, vdo.getTipo());
            pst.setString(3, vdo.getNome());
            pst.setString(4, vdo.getTamanho());
            pst.setString(5, vdo.getData());
            pst.execute();
            PreparedStatement pst1 = conex.con.prepareStatement("update video set Extensão_Vid = ?, Duração = ?, Qualidade_vid = ?, ID_VID = ?, caminho = ? where ID_VID = ?");
            pst1.setString(2, vdo.getDuracao());
            pst1.setString(3, vdo.getQualidade());
            pst1.setString(1, vdo.getExtencao());
            pst1.setInt(4, vdo.getId());
            pst1.setString(5, vdo.getCaminho());
            pst1.execute();
            JOptionPane.showMessageDialog(null, "Dados Alterados!");

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro, dado não alterado!");
        }
        conex.Dosconecta();
    }

    public void Excluir(Video img) {
        conex.Connection();
        try {
            PreparedStatement pst = conex.con.prepareStatement("delete from video where (Id =?)");
            pst.setInt(1, img.getId());
            JOptionPane.showMessageDialog(null, "Dados deletados com sucesso.");

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao deletar dados." + ex);
        }
        conex.Dosconecta();
    }
}
