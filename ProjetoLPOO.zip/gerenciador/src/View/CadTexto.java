package View;

import Controller.CadTextos;
import Connection.MyConnection;
import static Controller.Inf_arquivo.metodos;
import Model.ModeloTabela;
import Model.Texto;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;

public final class CadTexto extends javax.swing.JFrame {

    Texto txt = new Texto();
    MyConnection conex = new MyConnection();
    CadTextos control = new CadTextos();

    public CadTexto() {
        initComponents();
        preencherTabela("SELECT ID_IMG, Nome, Tipo, Dados_imagem FROM arquivos, imagem ORDER BY Nome");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jButtonImNovo = new javax.swing.JButton();
        jFormattedTextFieldImID = new javax.swing.JFormattedTextField();
        jLabelImID = new javax.swing.JLabel();
        jButtonSalvar = new javax.swing.JButton();
        jFormattedTextFieldImNome = new javax.swing.JFormattedTextField();
        jLabelImNome = new javax.swing.JLabel();
        jButtonCancelar = new javax.swing.JButton();
        jFormattedTextFieldImData = new javax.swing.JFormattedTextField();
        jLabel4 = new javax.swing.JLabel();
        jComboBoxImTipo = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        jButtonImEditar = new javax.swing.JButton();
        jFormattedTextFieldImCaminho = new javax.swing.JFormattedTextField();
        jLabel6 = new javax.swing.JLabel();
        jButtonImExcluir = new javax.swing.JButton();
        jComboBoxImQualidade = new javax.swing.JComboBox<>();
        jLabel7 = new javax.swing.JLabel();
        jComboBoxImExtencao = new javax.swing.JComboBox<>();
        jLabel8 = new javax.swing.JLabel();
        jFormattedTextFieldTamanho = new javax.swing.JFormattedTextField();
        jLabelTamanho = new javax.swing.JLabel();
        jButtonPesquisar = new javax.swing.JButton();
        jTextFieldImPesquisa = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableCadTexto = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jButtonImNovo.setText("Novo");
        jButtonImNovo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonImNovoActionPerformed(evt);
            }
        });

        jFormattedTextFieldImID.setEnabled(false);

        jLabelImID.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabelImID.setText("Id:");

        jButtonSalvar.setText("Salvar");
        jButtonSalvar.setEnabled(false);
        jButtonSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSalvarActionPerformed(evt);
            }
        });

        jFormattedTextFieldImNome.setEnabled(false);
        jFormattedTextFieldImNome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jFormattedTextFieldImNomeActionPerformed(evt);
            }
        });

        jLabelImNome.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabelImNome.setText("Nome:");

        jButtonCancelar.setText("Cancelar");
        jButtonCancelar.setEnabled(false);
        jButtonCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCancelarActionPerformed(evt);
            }
        });

        jFormattedTextFieldImData.setEnabled(false);

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel4.setText("Data:");

        jComboBoxImTipo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Imagem", "Video", "Texto", " " }));
        jComboBoxImTipo.setEnabled(false);
        jComboBoxImTipo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxImTipoActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel5.setText("Tipo:");

        jButtonImEditar.setText("Editar");
        jButtonImEditar.setEnabled(false);
        jButtonImEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonImEditarActionPerformed(evt);
            }
        });

        jFormattedTextFieldImCaminho.setEnabled(false);

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel6.setText("Caminho:");

        jButtonImExcluir.setText("Excluir");
        jButtonImExcluir.setEnabled(false);
        jButtonImExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonImExcluirActionPerformed(evt);
            }
        });

        jComboBoxImQualidade.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "50 a 500", "500 a 1000", "1000 a 1500", "1500 a 200" }));
        jComboBoxImQualidade.setEnabled(false);

        jLabel7.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel7.setText("Palavras:");

        jComboBoxImExtencao.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "PDF", "WORD", "TXT", " ", " " }));
        jComboBoxImExtencao.setEnabled(false);

        jLabel8.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel8.setText("Extenção:");

        jFormattedTextFieldTamanho.setEnabled(false);

        jLabelTamanho.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabelTamanho.setText("Tamanho:");

        jButtonPesquisar.setText("Pesquisar");
        jButtonPesquisar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonPesquisarActionPerformed(evt);
            }
        });

        jTextFieldImPesquisa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldImPesquisaActionPerformed(evt);
            }
        });

        jTableCadTexto.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(jTableCadTexto);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jButtonPesquisar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jTextFieldImPesquisa))
                    .addComponent(jScrollPane1)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                            .addComponent(jButtonImNovo, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(528, 528, 528))
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jButtonCancelar)
                                .addComponent(jButtonSalvar, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jButtonImExcluir, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jButtonImEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGap(22, 22, 22)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addComponent(jLabelTamanho)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(jFormattedTextFieldTamanho))
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addComponent(jLabelImID)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(jFormattedTextFieldImID))
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addComponent(jLabelImNome)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(jFormattedTextFieldImNome, javax.swing.GroupLayout.PREFERRED_SIZE, 462, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addComponent(jLabel4)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(jFormattedTextFieldImData))
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addComponent(jLabel5)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(jComboBoxImTipo, javax.swing.GroupLayout.PREFERRED_SIZE, 471, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addComponent(jLabel6)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(jFormattedTextFieldImCaminho, javax.swing.GroupLayout.PREFERRED_SIZE, 441, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addComponent(jLabel7)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(jComboBoxImQualidade, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addComponent(jLabel8)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(jComboBoxImExtencao, javax.swing.GroupLayout.PREFERRED_SIZE, 442, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jButtonImNovo)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButtonSalvar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButtonCancelar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButtonImEditar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButtonImExcluir))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabelImID)
                            .addComponent(jFormattedTextFieldImID, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabelImNome)
                            .addComponent(jFormattedTextFieldImNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(jFormattedTextFieldImData, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(jComboBoxImTipo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(jFormattedTextFieldImCaminho, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(jComboBoxImQualidade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(jComboBoxImExtencao, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabelTamanho)
                            .addComponent(jFormattedTextFieldTamanho, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 34, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButtonPesquisar)
                    .addComponent(jTextFieldImPesquisa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel1.setText("Cadastrar Texto");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(257, 257, 257)
                        .addComponent(jLabel1)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        setSize(new java.awt.Dimension(663, 532));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonImNovoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonImNovoActionPerformed
        jButtonSalvar.setEnabled(true);
        jFormattedTextFieldImID.setEnabled(true);
        jFormattedTextFieldImNome.setEnabled(true);
        jFormattedTextFieldImData.setEnabled(true);
        jComboBoxImTipo.setEnabled(true);
        jFormattedTextFieldImCaminho.setEnabled(true);
        jComboBoxImQualidade.setEnabled(true);
        jComboBoxImExtencao.setEnabled(true);
        jFormattedTextFieldTamanho.setEnabled(true);
    }//GEN-LAST:event_jButtonImNovoActionPerformed

    private void jButtonSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSalvarActionPerformed
        txt.setId(Integer.parseInt(jFormattedTextFieldImID.getText()));
        txt.setNome(jFormattedTextFieldImNome.getText());
        txt.setData(jFormattedTextFieldImData.getText());
        txt.setTipo((String) jComboBoxImTipo.getSelectedItem());
        metodos(jFormattedTextFieldImCaminho.getText());
        txt.setCaminho(jFormattedTextFieldImCaminho.getText());
        txt.setNum_palavras((String) jComboBoxImQualidade.getSelectedItem());
        txt.setExtencao((String) jComboBoxImExtencao.getSelectedItem());
        txt.setTamanho(jFormattedTextFieldTamanho.getText());
        control.Salvar(txt);

        jFormattedTextFieldImID.setText("");
        jFormattedTextFieldImNome.setText("");
        jFormattedTextFieldImData.setText("");
        jFormattedTextFieldImCaminho.setText("");
        jFormattedTextFieldTamanho.setText("");

        jButtonSalvar.setEnabled(false);
        jFormattedTextFieldImID.setEnabled(false);
        jFormattedTextFieldImNome.setEnabled(false);
        jFormattedTextFieldImData.setEnabled(false);
        jComboBoxImTipo.setEnabled(false);
        jFormattedTextFieldImCaminho.setEnabled(false);
        jComboBoxImQualidade.setEnabled(false);
        jComboBoxImExtencao.setEnabled(false);
        jFormattedTextFieldTamanho.setEnabled(false);
    }//GEN-LAST:event_jButtonSalvarActionPerformed

    private void jFormattedTextFieldImNomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jFormattedTextFieldImNomeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jFormattedTextFieldImNomeActionPerformed

    private void jComboBoxImTipoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxImTipoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxImTipoActionPerformed

    private void jTextFieldImPesquisaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldImPesquisaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFieldImPesquisaActionPerformed

    private void jButtonImExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonImExcluirActionPerformed

        int resposta = 0;
        resposta = JOptionPane.showConfirmDialog(rootPane, "Deseja realmente excluir?");
        if (resposta == JOptionPane.YES_OPTION) {

            txt.setId(Integer.parseInt(jFormattedTextFieldImID.getText()));
            control.Excluir(txt);
        }

    }//GEN-LAST:event_jButtonImExcluirActionPerformed

    private void jButtonImEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonImEditarActionPerformed

        jButtonSalvar.setEnabled(true);
        jFormattedTextFieldImID.setEnabled(true);
        jFormattedTextFieldImNome.setEnabled(true);
        jFormattedTextFieldImData.setEnabled(true);
        jComboBoxImTipo.setEnabled(true);
        jFormattedTextFieldImCaminho.setEnabled(true);
        jComboBoxImQualidade.setEnabled(true);
        jComboBoxImExtencao.setEnabled(true);
        jFormattedTextFieldTamanho.setEnabled(true);
        jButtonImNovo.setEnabled(false);
        jButtonImExcluir.setEnabled(false);
        jButtonImEditar.setEnabled(false);
    }//GEN-LAST:event_jButtonImEditarActionPerformed

    private void jButtonCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCancelarActionPerformed
        jButtonSalvar.setEnabled(!true);
        jFormattedTextFieldImID.setEnabled(!true);
        jFormattedTextFieldImNome.setEnabled(!true);
        jFormattedTextFieldImData.setEnabled(!true);
        jComboBoxImTipo.setEnabled(!true);
        jFormattedTextFieldImCaminho.setEnabled(!true);
        jComboBoxImQualidade.setEnabled(!true);
        jComboBoxImExtencao.setEnabled(!true);
        jFormattedTextFieldTamanho.setEnabled(!true);
    }//GEN-LAST:event_jButtonCancelarActionPerformed

    private void jButtonPesquisarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonPesquisarActionPerformed

        txt.setPesquisa(jTextFieldImPesquisa.getText());
        Texto txts = control.buscaTexto(txt);
        jFormattedTextFieldImID.setText(String.valueOf(txt.getId()));
        jFormattedTextFieldImNome.setText(txts.getNome());
        jComboBoxImExtencao.setSelectedItem(String.valueOf((txts.getExtencao())));
        jComboBoxImTipo.setSelectedItem(txts.getTipo());
        jButtonImEditar.setEnabled(true);
        jButtonImExcluir.setEnabled(true);
    }//GEN-LAST:event_jButtonPesquisarActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CadTexto().setVisible(true);
            }
        });
    }

    public void preencherTabela(String Sql) {
        ArrayList dados = new ArrayList();
        String[] colunas = new String[]{"ID", "Nome", "Tipo", "Caminho"};
        conex.Connection();
        conex.executaSql(Sql);
        try {
            conex.rs.first();
            // enquanto tiver dados ele apresenta
            do {
                dados.add(new Object[]{conex.rs.getInt("ID"), conex.rs.getString("Nome"), conex.rs.getString("Tipo"), conex.rs.getBlob("caminho")});

            } while (conex.rs.next());
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, "Lista de Textos vazia\n" + ex);
        }
        ModeloTabela modelo = new ModeloTabela(dados, colunas);

        jTableCadTexto.setModel(modelo);
        jTableCadTexto.getColumnModel().getColumn(0).setPreferredWidth(35);
        //aumentar tamanho da coluna 
        jTableCadTexto.getColumnModel().getColumn(0).setResizable(false);
        jTableCadTexto.getColumnModel().getColumn(1).setPreferredWidth(220);
        jTableCadTexto.getColumnModel().getColumn(1).setResizable(false);
        jTableCadTexto.getColumnModel().getColumn(2).setPreferredWidth(80);
        jTableCadTexto.getColumnModel().getColumn(2).setResizable(false);
        jTableCadTexto.getColumnModel().getColumn(1).setPreferredWidth(120);
        jTableCadTexto.getColumnModel().getColumn(1).setResizable(false);
        jTableCadTexto.getTableHeader().setReorderingAllowed(false);
        // TABELA NÃO PODE SER DIMENSIONADA
        jTableCadTexto.setAutoResizeMode(jTableCadTexto.AUTO_RESIZE_OFF);
        // só selecionar um dado por vêz
        jTableCadTexto.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        conex.Dosconecta();
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonCancelar;
    private javax.swing.JButton jButtonImEditar;
    private javax.swing.JButton jButtonImExcluir;
    private javax.swing.JButton jButtonImNovo;
    private javax.swing.JButton jButtonPesquisar;
    private javax.swing.JButton jButtonSalvar;
    private javax.swing.JComboBox<String> jComboBoxImExtencao;
    private javax.swing.JComboBox<String> jComboBoxImQualidade;
    private javax.swing.JComboBox<String> jComboBoxImTipo;
    private javax.swing.JFormattedTextField jFormattedTextFieldImCaminho;
    private javax.swing.JFormattedTextField jFormattedTextFieldImData;
    private javax.swing.JFormattedTextField jFormattedTextFieldImID;
    private javax.swing.JFormattedTextField jFormattedTextFieldImNome;
    private javax.swing.JFormattedTextField jFormattedTextFieldTamanho;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabelImID;
    private javax.swing.JLabel jLabelImNome;
    private javax.swing.JLabel jLabelTamanho;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTableCadTexto;
    private javax.swing.JTextField jTextFieldImPesquisa;
    // End of variables declaration//GEN-END:variables
}
